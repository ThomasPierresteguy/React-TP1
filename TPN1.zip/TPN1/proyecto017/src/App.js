import Tablero from './Tablero';
function App() {
  
  return (<div>
    <h1>Tablero de ajedrez con Drag and Drop 😀</h1>
    <Tablero/>
  </div>);
}

export default App;
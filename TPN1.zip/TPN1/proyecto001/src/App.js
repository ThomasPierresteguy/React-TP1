function App() {
  return (
    <h1>Hola mundo</h1>
  );
}

export default App;